var mysql = require("mysql");

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    pass: "",
    database: "water_taxdb"

});
module.exports = con;
