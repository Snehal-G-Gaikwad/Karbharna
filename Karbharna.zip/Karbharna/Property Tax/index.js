const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const port = 3000; // Change to your desired port

// MySQL Connection
const connection = mysql.createConnection({
  host: 'localhost',  // Your MySQL host
  user: 'root', // Your MySQL username
  password: 'Snehal@28', // Your MySQL password
  database: 'property_taxdb' // Your MySQL database name
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to database: ' + err.stack);
    return;
  }
  console.log('Connected to MySQL database as id ' + connection.threadId);
});

// Middleware to parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// Serve static files from 'public' directory (for CSS, etc.)
app.use(express.static('public'));

// Handle form submission
app.post('/post', (req, res) => {
  const { property_no, property_type, property_owner, owner_name, mobile_no, address, state, district, sub_district, village, grampanchayat, outstanding, rebate_amount, date, billing_type } = req.body;

  // Insert data into MySQL
  const sql = 'INSERT INTO property_data (property_no, property_type, property_owner, owner_name, mobile_no, address, state, district, sub_district, village, grampanchayat, outstanding, rebate_amount, date, billing_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
  
  connection.query(sql, [
    property_no, property_type, property_owner, owner_name, mobile_no, address, state, district, sub_district, village, grampanchayat, outstanding, rebate_amount, date, billing_type], 
    (err, result) => {
    if (err) {
      console.error('Error inserting into database: ' + err.stack);
      res.status(500).send('Error submitting form');
      return;
    }
    console.log('Data submitted successfully');
    res.status(200).send('Data submitted successfully');
  });
});

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
